// ================================
// CALCULATOR LOGIC
// ================================

let subjectCount = 1;
const MAX_SUBJECTS = 10;

// Initialize calculator
function initializeCalculator() {
    addSubject();
    
    document.getElementById('addSubjectBtn').addEventListener('click', addSubject);
    document.getElementById('calculateBtn').addEventListener('click', calculateGPA);
    document.getElementById('resetBtn').addEventListener('click', resetCalculator);
    document.getElementById('calculatorType').addEventListener('change', handleCalculatorTypeChange);
}

// Add subject input fields
function addSubject() {
    if (subjectCount >= MAX_SUBJECTS) {
        alert('Maximum 10 subjects allowed');
        return;
    }

    const container = document.getElementById('subjectsContainer');
    const subjectId = subjectCount++;
    
    const subjectGroup = document.createElement('div');
    subjectGroup.className = 'subject-input-group';
    subjectGroup.id = `subject-${subjectId}`;
    subjectGroup.innerHTML = `
        <input 
            type="text" 
            placeholder="Subject Name" 
            class="subject-name" 
            data-id="${subjectId}"
            required
        >
        <input 
            type="number" 
            placeholder="Credit Hours" 
            class="credit-hours" 
            data-id="${subjectId}"
            min="1" 
            max="10" 
            step="0.5"
            required
        >
        <input 
            type="number" 
            placeholder="Grade (0-4)" 
            class="grade-point" 
            data-id="${subjectId}"
            min="0" 
            max="4" 
            step="0.1"
            required
        >
        <button 
            type="button" 
            class="remove-subject-btn" 
            onclick="removeSubject(${subjectId})"
            title="Remove subject"
        >
            ✕
        </button>
    `;
    
    container.appendChild(subjectGroup);
}

// Remove subject
function removeSubject(id) {
    const element = document.getElementById(`subject-${id}`);
    if (element) {
        element.remove();
    }
    
    // Ensure at least one subject remains
    const container = document.getElementById('subjectsContainer');
    if (container.children.length === 0) {
        addSubject();
    }
}

// Calculate GPA/CGPA
function calculateGPA() {
    const calculatorType = document.getElementById('calculatorType').value;
    const subjects = [];
    
    // Get all subject inputs
    document.querySelectorAll('.subject-input-group').forEach(group => {
        const name = group.querySelector('.subject-name').value.trim();
        const credits = parseFloat(group.querySelector('.credit-hours').value);
        const grade = parseFloat(group.querySelector('.grade-point').value);
        
        if (name && !isNaN(credits) && !isNaN(grade) && credits > 0) {
            subjects.push({ name, credits, grade });
        }
    });
    
    if (subjects.length === 0) {
        alert('Please fill in at least one subject with valid data');
        return;
    }
    
    // Validate inputs
    for (let subject of subjects) {
        if (subject.grade < 0 || subject.grade > 4) {
            alert(`Invalid grade for ${subject.name}. Grade must be between 0 and 4`);
            return;
        }
        if (subject.credits < 0.5 || subject.credits > 10) {
            alert(`Invalid credit hours for ${subject.name}. Credits must be between 0.5 and 10`);
            return;
        }
    }
    
    // Calculate GPA
    const totalGradePoints = subjects.reduce((sum, subj) => sum + (subj.grade * subj.credits), 0);
    const totalCredits = subjects.reduce((sum, subj) => sum + subj.credits, 0);
    const gpa = totalGradePoints / totalCredits;
    
    // Determine letter grade
    let letterGrade = 'N/A';
    if (gpa >= 3.8) letterGrade = 'A+';
    else if (gpa >= 3.5) letterGrade = 'A';
    else if (gpa >= 3.0) letterGrade = 'B+';
    else if (gpa >= 2.5) letterGrade = 'B';
    else if (gpa >= 2.0) letterGrade = 'C+';
    else if (gpa >= 1.5) letterGrade = 'C';
    else if (gpa >= 1.0) letterGrade = 'D';
    else letterGrade = 'F';
    
    // Determine status
    let status = 'Good';
    if (gpa >= 3.5) status = 'Excellent';
    else if (gpa >= 3.0) status = 'Very Good';
    else if (gpa >= 2.0) status = 'Satisfactory';
    else status = 'Needs Improvement';
    
    // Display results
    displayResults(gpa, letterGrade, totalCredits, status, subjects);
}

// Display results
function displayResults(gpa, letterGrade, totalCredits, status, subjects) {
    const resultsSection = document.getElementById('resultsSection');
    
    document.getElementById('resultGPA').textContent = gpa.toFixed(2);
    document.getElementById('resultGrade').textContent = letterGrade;
    document.getElementById('resultCredits').textContent = totalCredits.toFixed(1);
    document.getElementById('resultStatus').textContent = status;
    
    // Create detailed message
    const message = `
        <strong>Summary:</strong><br>
        You completed ${subjects.length} subject(s) with a total of ${totalCredits.toFixed(1)} credit hours.<br>
        Your GPA/CGPA of <strong>${gpa.toFixed(2)}</strong> indicates ${getStatusMessage(gpa)}.
    `;
    document.getElementById('resultMessage').innerHTML = message;
    
    resultsSection.classList.remove('hidden');
    resultsSection.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Get status message
function getStatusMessage(gpa) {
    if (gpa >= 3.8) return 'outstanding academic performance';
    if (gpa >= 3.5) return 'excellent academic performance';
    if (gpa >= 3.0) return 'very good academic performance';
    if (gpa >= 2.5) return 'good academic performance';
    if (gpa >= 2.0) return 'satisfactory academic performance';
    if (gpa >= 1.5) return 'passing academic performance';
    return 'performance that may need improvement';
}

// Reset calculator
function resetCalculator() {
    document.getElementById('subjectsContainer').innerHTML = '';
    document.getElementById('resultsSection').classList.add('hidden');
    subjectCount = 1;
    addSubject();
}

// Handle calculator type change
function handleCalculatorTypeChange() {
    resetCalculator();
}

// ================================
// SLIDE FUNCTIONALITY
// ================================

let currentSlide = 0;
const slides = document.querySelectorAll('.slide-card');
const totalSlides = slides.length;

function initializeSlides() {
    if (totalSlides === 0) return;
    
    // Show first slide
    slides[0].classList.add('active');
    updateSlideIndicator();
    
    // Attach event listeners
    document.getElementById('prevSlide').addEventListener('click', previousSlide);
    document.getElementById('nextSlide').addEventListener('click', nextSlide);
    
    // Attach click listeners to slide numbers
    document.querySelectorAll('.slide-number-box').forEach((box, index) => {
        box.addEventListener('click', () => {
            toggleSlideNumberReveal(box);
        });
    });
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlides;
    updateSlide();
}

function previousSlide() {
    currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
    updateSlide();
}

function updateSlide() {
    slides.forEach(slide => slide.classList.remove('active'));
    slides[currentSlide].classList.add('active');
    updateSlideIndicator();
}

function updateSlideIndicator() {
    document.getElementById('slideIndicator').textContent = `${currentSlide + 1} / ${totalSlides}`;
}

function toggleSlideNumberReveal(box) {
    const isRevealed = box.classList.contains('revealed');
    
    if (!isRevealed) {
        // Show price
        const priceText = document.createElement('span');
        priceText.className = 'slide-number-text';
        priceText.textContent = '₨30';
        
        box.innerHTML = '';
        box.appendChild(priceText);
        box.classList.add('revealed');
        
        // Auto-hide after 3 seconds
        setTimeout(() => {
            if (box.classList.contains('revealed')) {
                const slideNum = currentSlide + 1;
                box.innerHTML = `<span class="slide-number-text">Slide ${slideNum}</span>`;
                box.classList.remove('revealed');
            }
        }, 3000);
    } else {
        // Hide price
        const slideNum = currentSlide + 1;
        box.innerHTML = `<span class="slide-number-text">Slide ${slideNum}</span>`;
        box.classList.remove('revealed');
    }
}

// ================================
// CONTACT FORM
// ================================

function initializeContactForm() {
    const contactForm = document.getElementById('contactForm');
    if (!contactForm) return;
    
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form values
        const name = this.querySelector('input[type="text"]').value;
        const email = this.querySelector('input[type="email"]').value;
        const message = this.querySelector('textarea').value;
        
        // Create mailto link
        const subject = 'Contact Form Submission';
        const body = `Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`;
        const mailtoLink = `mailto:contact@gpacalculator.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        
        // Open email client
        window.location.href = mailtoLink;
        
        // Reset form
        this.reset();
        alert('Email client opened. Please send the email to complete your message.');
    });
}

// ================================
// KEYBOARD NAVIGATION
// ================================

function initializeKeyboardNavigation() {
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowRight') {
            nextSlide();
        } else if (e.key === 'ArrowLeft') {
            previousSlide();
        }
    });
}

// ================================
// SMOOTH SCROLL
// ================================

function initializeSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// ================================
// INITIALIZE ALL
// ================================

document.addEventListener('DOMContentLoaded', function() {
    initializeCalculator();
    initializeSlides();
    initializeContactForm();
    initializeKeyboardNavigation();
    initializeSmoothScroll();
    
    // Log initialization
    console.log('GPA Calculator initialized successfully');
});

// ================================
// UTILITY FUNCTIONS
// ================================

// Format numbers
function formatNumber(num, decimals = 2) {
    return num.toFixed(decimals);
}

// Validate email
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}
